package com.netsharp.vpnapplication;

/**
 * Created by MMahasha on 2018/04/17.
 */

public class Cellc {
    private String firstname, lastname, idnumber, email, cell, address,company, manager, system, period, reason, date, status;

    public Cellc() {
    }

    public Cellc(String firstname, String lastname, String idnumber, String email, String cell,String company, String phone, String address, String manager,String system, String period, String reason, String date, String status) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.idnumber = idnumber;
        this.email = email;
        this.cell = cell;
        this.address = address;
        this.manager = manager;
        this.status = status;
        this.system = system;
        this.period = period;
        this.date = date;
        this.company = company;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(String idnumber) {
        this.idnumber = idnumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCell() {
        return cell;
    }

    public void setCell(String cell) {
        this.cell = cell;
    }



    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
}