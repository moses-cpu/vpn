package com.netsharp.vpnapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mcellcList;
    DatabaseReference mDatabase;
    Query query;
    FirebaseRecyclerAdapter<Cellc, CellcViewHolder> adapter;
    FirebaseRecyclerOptions<Cellc> options;
    LinearLayoutManager mLayoutManager;
    boolean isFirst = true;
    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            String toastText;
            Cellc post = new Cellc();
            for (DataSnapshot child : dataSnapshot.getChildren()) {
                post = child.getValue(Cellc.class);
            }
            toastText = "New Application: "+ post.getFirstname();
            if(!isFirst){
                notifyThis(post.getFirstname(), post.getCompany()+" "+post.getCell());
                Toast.makeText(getApplicationContext(), toastText, Toast.LENGTH_LONG).show();
            }
            //mcellcList.smoothScrollToPosition(adapter.getItemCount()-1);

        }

        @Override
        public void onCancelled(DatabaseError databaseError) {
            Log.i("FirebaseError", databaseError.getMessage());
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //getActionBar().hide();
        mcellcList = (RecyclerView) findViewById(R.id.cellc_list);
        mcellcList.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mLayoutManager.setReverseLayout(true);
        mLayoutManager.setStackFromEnd(true);
        mcellcList.setLayoutManager(mLayoutManager);
        mDatabase = FirebaseDatabase.getInstance().getReference().child("vpnapp");
        mDatabase.addValueEventListener(valueEventListener);
        query = mDatabase;

        options =
                new FirebaseRecyclerOptions.Builder<Cellc>()
                        .setQuery(query, Cellc.class)
                        .build();
        adapter = new FirebaseRecyclerAdapter<Cellc, CellcViewHolder>(options) {
            @Override
            public CellcViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.cellc_row, parent, false);
                return new CellcViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(CellcViewHolder holder, int position, Cellc model) {
                holder.setfirstname(model.getFirstname());
                holder.setlastname(model.getLastname());
                holder.setidnumber(model.getIdnumber());
                holder.setemail(model.getEmail());
                holder.setcell(model.getCell());
                holder.setaddress(model.getAddress());
                holder.setmanager(model.getManager());
                holder.setStatus(model.getStatus());
                holder.setDate(model.getDate());
                holder.setReason(model.getReason());
                holder.setSystem(model.getSystem());
                holder.setPeriod(model.getPeriod());
                holder.setCompany(model.getCompany());
            }
        };
        mcellcList.setAdapter(adapter);
        adapter.startListening();
    }

    private int lastClickedItemPosition;

    public int getLastClickedItemPosition() {
        return lastClickedItemPosition;
    }

    class CellcViewHolder extends RecyclerView.ViewHolder {
        private Button approve;


        public CellcViewHolder(View itemView) {
            super(itemView);
            View mView = itemView;
            approve = (Button) itemView.findViewById(R.id.btnApprove);
            approve.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    lastClickedItemPosition = getAdapterPosition();
                    if(approve.getText().equals("APPROVED"))
                    {
                        AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                        builder.setCancelable(true);
                        builder.setTitle("Notification");
                        builder.setMessage("Already approved");
                        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // v.getContext().startActivity(new Intent(v.getContext(),NoticeAdminRecycler.class));
                                dialog.dismiss();
                            }
                        });
                        builder.show();
                        return;
                    }
                    AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                    final View view = v;
                    builder.setTitle("Confirm");
                    builder.setMessage("Are you sure want to Approve Record?");

                    builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {

                            updateValue(view);
                            // Toast.makeText(view.getContext(), holder.title.getText()+" "+key, Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }
                    });

                    builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            // Do nothing
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });
        }

        public void setfirstname(String firstname) {
            TextView post_title = (TextView) itemView.findViewById(R.id.firstname);
            ImageView icon_image = (ImageView) itemView.findViewById(R.id.icon_image);
            post_title.setText(firstname);
            icon_image.setImageDrawable(getResources().getDrawable(R.mipmap.p3));
        }

        public void setlastname(String lastname) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.lastname);
            post_desc.setText(lastname);
        }

        public void setidnumber(String idnumber) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.idnumber);
            post_desc.setText(idnumber);
        }

        public void setemail(String email) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.emaill);
            post_desc.setText(email);
        }

        public void setcell(String cell) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.cell);
            post_desc.setText(cell);
        }

        public void setaddress(String address) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.address);
            post_desc.setText(address);
        }

        public void setmanager(String manager) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.manager);
            post_desc.setText(manager);
        }
        public void setDate(String date) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.date);
            post_desc.setText(date);
        }
        public void setReason(String reason) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.reason);
            post_desc.setText(reason);
        }
        public void setCompany(String company) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.company);
            post_desc.setText(company);
        }
        public void setPeriod(String period) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.period);
            post_desc.setText(period);
        }
        public void setSystem(String system) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.system);
            post_desc.setText(system);
        }

        public void setStatus(String status) {
            TextView post_desc = (TextView) itemView.findViewById(R.id.hospitalref);
            post_desc.setText(status);
            Button approver = (Button) itemView.findViewById(R.id.btnApprove);
            if(status.equals("NotApproved")){
                approver.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.btnapprove));
                approver.setText("APPROVE");
            }

            else if(status.equals("Approved")){
                approver.setText("APPROVED");
                approver.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.btnapprovenot));
            }else
                approver.setText("N/A");

        }
    }

    public void updateValue(final View v) {
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int i = 0;

                String key = "";
                for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                    if (i == getLastClickedItemPosition())
                        key = childSnapshot.getKey();
                    i++;
                }
                mDatabase.child(key).child("status").setValue("Approved").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                        builder.setCancelable(true);
                        builder.setTitle("Success");
                        builder.setMessage("Data is Updated Successfully ! Please refresh the activity to reflect the changes.");
                        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // v.getContext().startActivity(new Intent(v.getContext(),NoticeAdminRecycler.class));
                                dialog.dismiss();
                            }
                        });
                        builder.show();
                        Toast.makeText(v.getContext(), "Data Saved", Toast.LENGTH_SHORT).show();
                    }
                });
            }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(v.getContext(), "Database Error!!", Toast.LENGTH_SHORT).show();

                    }
                });
            }

    public void notifyThis(String title, String message) {
        NotificationCompat.Builder b = new NotificationCompat.Builder(getApplicationContext(),"1");
        b.setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.mipmap.ic_launcher)
                .setTicker("VPN CellC")
                .setContentTitle(title)
                .setContentText(message)
                .setContentInfo("INFO");

        try {
            Intent notification = new Intent(getApplicationContext(), MainActivity.class);
            notification.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent contentIntent = PendingIntent.getActivity(getApplicationContext(), 0,notification
                    , PendingIntent.FLAG_UPDATE_CURRENT);
            b.setContentIntent(contentIntent);
            NotificationManager nm = (NotificationManager) getApplication().getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(0, b.build());
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {

        }

    }
    @Override
    protected void onResume()
    {
        super.onResume();
        isFirst = false;


    }

}
